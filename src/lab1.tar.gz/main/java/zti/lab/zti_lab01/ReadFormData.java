package zti.lab.zti_lab01;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet(name = "ReadFormData", value = "/ReadFormData")
public class ReadFormData extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out= response.getWriter();
        String fname = request.getParameterValues("fname")[0] ;
        String lname = request.getParameterValues("lname")[0] ;
        String city = request.getParameterValues("city")[0] ;

        out.println("<h1>Dane przesłane z formularza</h1>") ;
        out.println("<table>") ;
        out.println("<tr><td>Imię: </td><td>" +  fname + "</td></tr>");
        out.println("<tr><td>Nazwisko: </td><td>" +  lname + "</td></tr>");
        out.println("<tr><td>Miasto: </td><td>" +  city + "</td></tr>");
        out.println("</body></html>");

        try
        {
            Class.forName("org.postgresql.Driver");
            String url = "jdbc:postgresql://cornelius.db.elephantsql.com:5432/rpuuyubi";
            String username = "rpuuyubi" ;
            String password = "OoyWtEXDRbDXZ9NA1idNLjDKLx0ORP2F" ;
            Connection conn = DriverManager.getConnection(url, username, password);
            PreparedStatement  stmt = conn.prepareStatement("INSERT INTO public.person (fname, lname, city) VALUES (?, ?, ?)");
            stmt.setString(1, fname);
            stmt.setString(2, lname);
            stmt.setString(3, city);

            stmt.executeUpdate();
            stmt.close();
            conn.close();
        }
        catch(Exception e)
        {  out.println (e) ; }
    }
}