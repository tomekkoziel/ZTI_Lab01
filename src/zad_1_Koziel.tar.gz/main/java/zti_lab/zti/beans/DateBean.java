package zti_lab.zti.beans;

import java.util.Date;

public class DateBean {

    private Date currentDate = new Date();

    public Date getCurrentDate() {
        return currentDate;
    }

}